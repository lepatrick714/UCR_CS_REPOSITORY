figure(1);
disp('Iris:');
runknn('iris.dat',65,35,50,21);

figure(2);
disp('Vert:');
runknn('vert.dat',155,62,93,51);
